# 

from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


class SemanticMatcher:

    def __init__(self):
        print("Loading semantic model...")
        self.model = SentenceTransformer("all-MiniLM-L6-v2")

    def analyze(self, question: str, answer: str):

        q_embedding = self.model.encode(
            question,
            convert_to_numpy=True
        )

        a_embedding = self.model.encode(
            answer,
            convert_to_numpy=True
        )

        similarity = cosine_similarity(
            [q_embedding],
            [a_embedding]
        )[0][0]

        similarity = float(similarity)

        # Normalize to 0-100
        semantic_score = similarity * 100

        return {
            "similarity": round(similarity, 4),
            "score": round(semantic_score, 2)
        }