# from semantic_match import SemanticMatcher


# def main():

#     matcher = SemanticMatcher()

#     question = input("Question: ")
#     answer = input("Answer: ")

#     similarity = matcher.get_similarity(
#         question,
#         answer
#     )

#     score = matcher.similarity_to_score(
#         similarity
#     )

#     print("\n----- Semantic Analysis -----")
#     print(f"Similarity : {similarity:.4f}")
#     print(f"Score      : {score}/25")


# if __name__ == "__main__":
#     main()

from semantic_match import SemanticMatcher


def main():

    matcher = SemanticMatcher()

    question = input("Question: ")
    answer = input("Answer: ")

    result = matcher.analyze(
        question,
        answer
    )

    print("\n----- Semantic Analysis -----")
    print(f"Similarity : {result['similarity']}")
    print(f"Score      : {result['score']}/100")


if __name__ == "__main__":
    main()