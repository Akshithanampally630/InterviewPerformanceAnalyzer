# import spacy

# # Load spaCy model
# nlp = spacy.load("en_core_web_sm")

# # Step 1: basic filler dictionary
# FILLER_WORDS = {
#     "um", "uh", "like", "you know",
#     "actually", "basically", "sort of", "kind of"
# }

# # Step 2: check if token is filler (context-aware)
# def is_filler(token, prev_token=None, next_token=None):
#     word = token.text.lower()

#     # multi-word fillers handled separately later
#     if word in {"like", "actually", "basically"}:

#         # POS filter (important for "like")
#         if word == "like":
#             if token.pos_ in {"VERB"}:
#                 return False

#         # position-based penalty boost
#         if token.i == 0:  # sentence start
#             return True

#         return True

#     if word in FILLER_WORDS:
#         return True

#     return False


# # Step 3: main filler detection function
# def analyze_filler(text):
#     doc = nlp(text.lower())

#     total_tokens = 0
#     filler_tokens = 0

#     filler_details = []

#     for sent in doc.sents:
#         tokens = list(sent)

#         for i, token in enumerate(tokens):
#             if token.is_punct or token.is_space:
#                 continue

#             total_tokens += 1

#             prev_token = tokens[i - 1] if i > 0 else None
#             next_token = tokens[i + 1] if i < len(tokens) - 1 else None

#             if is_filler(token, prev_token, next_token):
#                 filler_tokens += 1
#                 filler_details.append({
#                     "word": token.text,
#                     "position": token.i,
#                     "sentence": sent.text
#                 })

#     filler_ratio = (
#         filler_tokens / total_tokens if total_tokens > 0 else 0
#     )

#     return {
#         "total_tokens": total_tokens,
#         "filler_tokens": filler_tokens,
#         "filler_ratio": round(filler_ratio, 4),
#         "filler_instances": filler_details
#     }
# def generate_report(result):
#     ratio = result["filler_ratio"] * 100
#     fillers = result["filler_instances"]

#     # categorize severity
#     if ratio < 5:
#         level = "🟢 Low"
#         comment = "Very clear communication."
#     elif ratio < 15:
#         level = "🟡 Moderate"
#         comment = "Some hesitation detected."
#     else:
#         level = "🔴 High"
#         comment = "Frequent filler usage affecting clarity."

#     # unique filler words
#     unique_fillers = list(set([f["word"] for f in fillers]))

#     report = f"""
# 📊 Filler Word Analysis

# 🔹 Filler Ratio: {ratio:.1f}% ({level})

# 🧠 Interpretation:
# {comment}

# ⚠️ Detected filler words:
# """

#     for word in unique_fillers:
#         report += f"- \"{word}\"\n"

#     report += """
# 💡 Improvement Tip:
# Pause instead of using filler words. Speak slower, structure thoughts before speaking.
# """

#     return report

# # ----------------- TEST -----------------
# if __name__ == "__main__":
#     text = "I like basically worked on a project and you know it was actually interesting"

#     result = analyze_filler(text)

#     print("\n📊 Filler Analysis Result:")
#     print(result)

#     report = generate_report(result)
#     print("\n📄 Generated Report:")
#     print(report)

import spacy

nlp = spacy.load("en_core_web_sm")

FILLER_WORDS = {
    "um", "uh", "like", "you know",
    "actually", "basically",
    "sort of", "kind of"
}


def is_filler(token):

    word = token.text.lower()

    if word == "like":
        if token.pos_ == "VERB":
            return False

    return word in {
        "um",
        "uh",
        "like",
        "actually",
        "basically"
    }


def filler_score(answer):

    doc = nlp(answer)

    total_tokens = 0
    filler_tokens = 0

    filler_words_found = []

    for token in doc:

        if token.is_punct or token.is_space:
            continue

        total_tokens += 1

        if is_filler(token):

            filler_tokens += 1

            filler_words_found.append(
                token.text.lower()
            )

    filler_ratio = (
        filler_tokens / total_tokens
        if total_tokens > 0
        else 0
    )

    # -----------------------------
    # Convert to score out of 100
    # -----------------------------

    if filler_tokens <= 2:
        score = 100

    elif filler_tokens <= 5:
        score = 80

    elif filler_tokens <= 10:
        score = 60

    else:
        score = 30

    return {
        "count": filler_tokens,
        "ratio": round(filler_ratio * 100, 2),
        "fillers": list(set(filler_words_found)),
        "score": score
    }