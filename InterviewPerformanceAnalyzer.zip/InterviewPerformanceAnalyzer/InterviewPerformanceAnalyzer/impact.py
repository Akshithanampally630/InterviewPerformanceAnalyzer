# import re

# ACTION_WORDS = [
#     "built",
#     "developed",
#     "implemented",
#     "designed",
#     "created",
#     "optimized",
#     "improved",
#     "reduced",
#     "increased",
#     "automated"
# ]

# OUTCOME_WORDS = [
#     "faster",
#     "efficient",
#     "performance",
#     "latency",
#     "scalable",
#     "reliable",
#     "saved",
#     "automation"
# ]


# def impact_score(answer):

#     answer = answer.lower()

#     score = 0

#     # ownership/action
#     action_count = sum(
#         1 for word in ACTION_WORDS
#         if word in answer
#     )

#     score += min(action_count * 2, 6)

#     # outcome/result
#     outcome_count = sum(
#         1 for word in OUTCOME_WORDS
#         if word in answer
#     )

#     score += min(outcome_count * 2, 6)

#     # metrics bonus
#     metrics = len(re.findall(r"\d+", answer))

#     score += min(metrics, 3)

#     return min(score, 15)
import re

ACTION_WORDS = [
    "built",
    "developed",
    "implemented",
    "designed",
    "created",
    "optimized",
    "improved",
    "reduced",
    "increased",
    "automated"
]

OUTCOME_WORDS = [
    "faster",
    "efficient",
    "performance",
    "latency",
    "scalable",
    "reliable",
    "saved",
    "automation"
]


def impact_score(answer):

    answer = answer.lower()

    raw_score = 0

    action_found = [
        word for word in ACTION_WORDS
        if word in answer
    ]

    outcome_found = [
        word for word in OUTCOME_WORDS
        if word in answer
    ]

    metrics_found = re.findall(r"\d+", answer)

    # Action signals
    raw_score += min(len(action_found) * 2, 6)

    # Outcome signals
    raw_score += min(len(outcome_found) * 2, 6)

    # Metrics bonus
    raw_score += min(len(metrics_found), 3)

    raw_score = min(raw_score, 15)

    # Normalize to 0-100
    normalized_score = (raw_score / 15) * 100

    return {
        "raw_score": raw_score,
        "score": round(normalized_score, 2),
        "actions_detected": action_found,
        "outcomes_detected": outcome_found,
        "metrics_detected": metrics_found
    }