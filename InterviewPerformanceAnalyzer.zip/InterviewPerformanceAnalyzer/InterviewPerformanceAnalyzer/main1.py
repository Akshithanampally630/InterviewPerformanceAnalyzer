# from star_detector import STARDetector

# API_KEY = "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"

# detector = STARDetector(API_KEY)

# answer = """
# During my internship, our API response time was slow.

# My task was to improve performance.

# I added database indexing and optimized SQL queries.
# """

# result = detector.score(answer)

# print(result)

from star_detector import STARDetector

GROQ_API_KEY = "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"

star_detector = STARDetector(GROQ_API_KEY)