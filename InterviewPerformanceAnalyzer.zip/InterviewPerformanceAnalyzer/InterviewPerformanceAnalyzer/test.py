from google import genai

client = genai.Client(api_key="AQ.Ab8RN6IqjpSpxvpCL6GRnA7KYGjYJkJ56gspkvJsjl_SMi-Diw")

response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents="Explain about AI in two lines."
)

print(response.text)