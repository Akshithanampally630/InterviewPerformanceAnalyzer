# from transformers import pipeline

# classifier = pipeline(
#     "sentiment-analysis",
#     model="distilbert-base-uncased-finetuned-sst-2-english"
# )

# text = "Iam okay doing this job"

# result = classifier(text)[0]

# print("Sentiment:", result["label"])
# print("Confidence:", round(result["score"] * 100, 2), "%")

from transformers import pipeline

# Load once
classifier = pipeline(
    "sentiment-analysis",
    model="distilbert-base-uncased-finetuned-sst-2-english"
)


def sentiment_analysis(answer):

    result = classifier(answer)[0]

    label = result["label"]
    confidence = result["score"] * 100

    # Normalize to 0-100 score
    if label == "POSITIVE":
        sentiment_score = confidence

    else:
        sentiment_score = 100 - confidence

    return {
        "label": label,
        "confidence": round(confidence, 2),
        "score": round(sentiment_score, 2)
    }