def calculate_confidence(
    question_type,
    semantic,
    sentiment,
    fillers,
    impact,
    star
):

    if question_type == "Behavioral":

        return (
            semantic * 0.35 +
            star * 0.35 +
            impact * 0.15 +
            fillers * 0.10 +
            sentiment * 0.05
        )

    elif question_type == "Project Based":

        return (
            semantic * 0.40 +
            star * 0.25 +
            impact * 0.15 +
            fillers * 0.10 +
            sentiment * 0.10
        )

    else:  # Technical Concept

        return (
            semantic * 0.75 +
            fillers * 0.15 +
            sentiment * 0.10
        )