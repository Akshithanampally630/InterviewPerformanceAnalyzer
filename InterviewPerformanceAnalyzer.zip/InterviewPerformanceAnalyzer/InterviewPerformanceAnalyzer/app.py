import streamlit as st
from semantic_match import SemanticMatcher
from sentiment import sentiment_analysis
from fillers import filler_score
from impact import impact_score
from star_detector import STARDetector
from confidence_engine import calculate_confidence
from google import genai
import whisper
import tempfile

# =========================
# LOAD MODELS ONCE
# =========================

semantic_matcher = SemanticMatcher()
whisper_model = whisper.load_model("base")
client = genai.Client(api_key="AQ.Ab8RN6IqjpSpxvpCL6GRnA7KYGjYJkJ56gspkvJsjl_SMi-Diw")
GROQ_API_KEY = "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"

star_detector = STARDetector(GROQ_API_KEY)

# =========================
# AI FUNCTIONS
# =========================

def improve_answer(user_input):
    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=f"""
You are an interview coach.

Improve the following answer to make it:
- Confident
- Professional
- Clear
- Impactful

Answer:
"{user_input}"

Give only the improved answer.
"""
        )
        return response.text
    except Exception as e:
        return f"Error: {str(e)}"


def summarize_answer(user_input):
    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=f"""
Summarize the following interview answer in 2-3 concise lines.

Answer:
"{user_input}"
"""
        )
        return response.text
    except Exception as e:
        return f"Error: {str(e)}"


def speech_to_text(audio_file):
    try:
        file_type = audio_file.name.split('.')[-1]

        with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_type}") as tmp:
            tmp.write(audio_file.read())
            temp_audio_path = tmp.name

        result = whisper_model.transcribe(temp_audio_path)
        return result["text"]

    except Exception as e:
        return None
# =========================
# UI
# =========================

st.set_page_config(
    page_title="Interview Performance Analyzer",
    page_icon="🎯",
    layout="centered"
)

st.title("🎯 Interview Performance Analyzer")

question_type = st.selectbox(
    "Select Question Type",
    [
        "Behavioral",
        "Project Based",
        "Technical Concept"
    ]
)

question = st.text_area(
    "Interview Question",
    height=100
)

answer = st.text_area(
    "Candidate Answer",
    height=250
)

audio_file = st.file_uploader(
    "Upload your answer (audio)",
    type=["wav", "mp3", "mpeg"]
)
# =========================
# ANALYZE BUTTON
# =========================

if st.button("Analyze Answer"):

    # =========================
    # 🎤 STEP 1: AUDIO → TEXT FIRST
    # =========================
    if audio_file is not None:
        with st.spinner("Converting speech to text..."):
            answer = speech_to_text(audio_file)

        if answer:
            st.success("Audio converted successfully!")
            st.write("🗣 Converted Text:", answer)
        else:
            st.error("Failed to process audio")
            st.stop()

    # =========================
    # ✅ STEP 2: VALIDATION AFTER CONVERSION
    # =========================
    if not question.strip() or not answer.strip():
        st.warning("Please enter both question and answer.")
        st.stop()

    # =========================
    # MODULE 1 : SEMANTIC
    # =========================
    semantic_result = semantic_matcher.analyze(question, answer)
    semantic_score = semantic_result["score"]

    # =========================
    # MODULE 2 : SENTIMENT
    # =========================
    sentiment_result = sentiment_analysis(answer)
    sentiment_score = sentiment_result["score"]

    # =========================
    # MODULE 3 : FILLERS
    # =========================
    filler_result = filler_score(answer)
    filler_score_value = filler_result["score"]

    # =========================
    # MODULE 4 : IMPACT
    # =========================
    impact_value = 0
    if question_type != "Technical Concept":
        impact_result = impact_score(answer)
        impact_value = impact_result["score"]

    # =========================
    # MODULE 5 : STAR
    # =========================
    star_value = 0
    star_breakdown = None

    if question_type != "Technical Concept":
        star_result = star_detector.score(answer)
        star_breakdown = star_result["breakdown"]
        star_value = star_result["score"]

    # =========================
    # FINAL CONFIDENCE
    # =========================
    confidence = calculate_confidence(
        question_type=question_type,
        semantic=semantic_score,
        sentiment=sentiment_score,
        fillers=filler_score_value,
        impact=impact_value,
        star=star_value
    )

    # =========================
    # DISPLAY RESULTS
    # =========================
    st.success(f"Overall Confidence Score: {confidence:.2f}/100")

    st.subheader("Detailed Scores")
    st.write(f"Semantic Match : {semantic_score:.2f}")
    st.write(f"Sentiment      : {sentiment_score:.2f}")
    st.write(f"Fillers        : {filler_score_value:.2f}")

    if question_type != "Technical Concept":
        st.write(f"Impact Signal  : {impact_value:.2f}")
        st.write(f"STAR Score     : {star_value:.2f}")

    if star_breakdown:
        st.subheader("STAR Breakdown")
        st.json(star_breakdown)

    # =========================
    # VERDICT
    # =========================
    if confidence >= 90:
        verdict = "Excellent"
    elif confidence >= 80:
        verdict = "Strong"
    elif confidence >= 70:
        verdict = "Good"
    elif confidence >= 60:
        verdict = "Average"
    else:
        verdict = "Needs Improvement"

    st.subheader("Verdict")
    st.info(verdict)

    # =========================
    # AI IMPROVEMENT
    # =========================
    st.subheader("✨ AI Improved Answer")

    with st.spinner("Improving your answer..."):
        improved = improve_answer(answer)

    if "Error" in improved:
        st.error(improved)
    else:
        st.success(improved)

    # =========================
    # AI SUMMARY
    # =========================
    st.subheader("🧠 AI Summary")

    with st.spinner("Summarizing..."):
        summary = summarize_answer(answer)

    if "Error" in summary:
        st.error(summary)
    else:
        st.info(summary)