# import json
# from openai import OpenAI


# class STARDetector:

#     def __init__(self, api_key):
#         self.client = OpenAI(
#             api_key=api_key,
#             base_url="https://api.groq.com/openai/v1"
#         )

#     def analyze(self, answer):

#         prompt = f"""
# You are an interview evaluator.

# Analyze the answer and detect whether it contains:

# 1. Situation
# 2. Task
# 3. Action
# 4. Result

# Return ONLY valid JSON.

# Example:

# {{
#     "situation": true,
#     "task": true,
#     "action": true,
#     "result": false
# }}

# Answer:
# {answer}
# """

#         response = self.client.chat.completions.create(
#             model="llama-3.3-70b-versatile",
#             messages=[
#                 {
#                     "role": "user",
#                     "content": prompt
#                 }
#             ],
#             temperature=0
#         )

#         text = response.choices[0].message.content.strip()

#         text = text.replace("```json", "").replace("```", "").strip()

#         return json.loads(text)

#     def score(self, answer):

#         result = self.analyze(answer)

#         score = 0

#         if result["situation"]:
#             score += 5

#         if result["task"]:
#             score += 5

#         if result["action"]:
#             score += 5

#         if result["result"]:
#             score += 10

#         return {
#             "breakdown": result,
#             "score": score
#         }

import json
from openai import OpenAI


class STARDetector:

    def __init__(self, api_key):
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://api.groq.com/openai/v1"
        )

    def analyze(self, answer):

        prompt = f"""
You are an interview evaluator.

Analyze the candidate's answer and determine whether it contains:

1. Situation
2. Task
3. Action
4. Result

Return ONLY valid JSON.

Format:

{{
    "situation": true,
    "task": true,
    "action": true,
    "result": true
}}

Answer:
{answer}
"""

        response = self.client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0
        )

        text = response.choices[0].message.content.strip()

        text = text.replace("```json", "")
        text = text.replace("```", "")
        text = text.strip()

        return json.loads(text)

    def score(self, answer):

        result = self.analyze(answer)

        raw_score = 0

        if result.get("situation", False):
            raw_score += 5

        if result.get("task", False):
            raw_score += 5

        if result.get("action", False):
            raw_score += 5

        if result.get("result", False):
            raw_score += 10

        normalized_score = (raw_score / 25) * 100

        return {
            "raw_score": raw_score,
            "score": round(normalized_score, 2),
            "breakdown": result
        }